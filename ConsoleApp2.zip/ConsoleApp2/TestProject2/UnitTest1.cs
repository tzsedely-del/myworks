using N�vT�r;

namespace TestProject2
{
    public class Tests
    {
        [SetUp]
        public void Setup()
        {
        }

        [Test]
        [TestCase (-1,"als� hiba")]
        [TestCase (1,"csecsem�")]
        [TestCase (6,"gyerek")]
        [TestCase (64,"feln�tt")]
       [TestCase (132,"fels� hiba")]
        public void Test1(double �letkor,string expected)
        {
            Oszt�lyoz� target = new Oszt�lyoz�();
            string actual = target.Oszt�lyoz(�letkor);
            Assert.AreEqual(expected, actual);

        }
        public void Test1()
        {
            Assert.Pass();
        }
    }
}