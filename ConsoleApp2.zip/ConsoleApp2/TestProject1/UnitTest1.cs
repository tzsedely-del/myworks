using Microsoft.VisualStudio.TestTools.UnitTesting;
using N�vT�r;
using NUnit.Framework;
using System.Runtime.CompilerServices;
using Assert = Microsoft.VisualStudio.TestTools.UnitTesting.Assert;

namespace TestProject1
{
    [TestClass]
    public class UnitTest1
    {
     [TestMethod]
        public void TestMethod1()
        {
            //target,fix param�terek,expected,actual,equal
            Oszt�lyoz� target = new Oszt�lyoz�();
            int �letkor = -1;
            string expected = "als� hiba";
            string actual = target.Oszt�lyoz(�letkor);
            Assert.AreEqual(expected, actual);

        }
       

        [TestMethod]
        public void TestMethod2()
        {
            //target,fix param�terek,expected,actual,equal
            Oszt�lyoz� target = new Oszt�lyoz�();
            int �letkor = 1;
            string expected = "csecsem�";
            string actual = target.Oszt�lyoz(�letkor);
            Assert.AreEqual(expected, actual);

        }
        [TestMethod]
        public void TestMethod3()
        {
            //target,fix param�terek,expected,actual,equal
            Oszt�lyoz� target = new Oszt�lyoz�();
            int �letkor = 6;
            string expected = "gyerek";
            string actual = target.Oszt�lyoz(�letkor);
            Assert.AreEqual(expected, actual);

        }

        [TestMethod]
        public void TestMethod4()
        {
            //target,fix param�terek,expected,actual,equal
            Oszt�lyoz� target = new Oszt�lyoz�();
            int �letkor = 15;
            string expected = "tini";
            string actual = target.Oszt�lyoz(�letkor);
            Assert.AreEqual(expected, actual);

        }
        [TestMethod]
        public void TestMethod5()
        {
            //target,fix param�terek,expected,actual,equal
            Oszt�lyoz� target = new Oszt�lyoz�();
            int �letkor = 64;
            string expected = "feln�tt";
            string actual = target.Oszt�lyoz(�letkor);
            Assert.AreEqual(expected, actual);

        }

        [TestMethod]
        public void TestMethod6()
        {
            //target,fix param�terek,expected,actual,equal
            Oszt�lyoz� target = new Oszt�lyoz�();
            int �letkor = 132;
            string expected = "fels� hiba";
            string actual = target.Oszt�lyoz(�letkor);
            Assert.AreEqual(expected, actual);
        }
        
        

        
        [TestMethod]
        [ExpectedException(typeof(Exception),"als� hiba")]
        [Expec]
        public void TestMethod7()
        {
            Oszt�lyoz� target = new Oszt�lyoz�();
            double �letkor = 132;
            target.Oszt�lyoz(�letkor);
        }
    }
}