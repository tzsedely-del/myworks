﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApplication2
{
    public class Rendeles
    {
        public Vasarlo Vasarlo { get; set; }
        public List<Termek> Termekek { get; set; } = new List<Termek>();
        public bool VanKupon { get; set; }
        public string KuponKod { get; set; }
        public string FizetesiMod { get; set; }
        public bool ElfogadottAdatvedelmiNyilatkozat { get; set; }
    }

}
