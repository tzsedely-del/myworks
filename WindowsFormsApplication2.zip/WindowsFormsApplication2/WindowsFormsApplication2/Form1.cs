﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication2
{
    public partial class Form1 : Form
    {
        public Vasarlo Vasarlo { get; set; }

        public Form1()
        {
            InitializeComponent();
        }

        private void btnKovetkezo_Click(object sender, EventArgs e)
        {
            // Ellenőrizzük a szükséges adatokat
            if (string.IsNullOrEmpty(txtNev.Text) || string.IsNullOrEmpty(txtTelefon.Text))
            {
                MessageBox.Show("A név és a telefonszám megadása kötelező.");
                return;
            }

            Vasarlo = new Vasarlo
            {
                Nev = txtNev.Text,
                Telefon = txtTelefon.Text,
                Varos = cboVaros.SelectedItem.ToString(),
                Cim = txtCim.Text
            };

            var form2 = new Form2(Vasarlo);
            form2.Show();
            this.Hide();
        }
    }
}